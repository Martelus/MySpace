﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ1_C_LVL1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Написать программу «Анкета». Последовательно задаются вопросы(имя, фамилия, возраст, рост, вес).
            //В результате вся информация выводится в одну строчку:
            //а) используя склеивание;
            //б) используя форматированный вывод;
            //в) используя вывод со знаком $.
            string name, surname, age, height, weight;
            Console.WriteLine("Enter your name");
            name = Console.ReadLine();
            Console.WriteLine("Enter your surname");
            surname = Console.ReadLine();
            Console.WriteLine("Enter your age");
            age = Console.ReadLine();
            Console.WriteLine("Enter your height");
            height = Console.ReadLine();
            Console.WriteLine("Enter your weight");
            weight = Console.ReadLine();
            Console.WriteLine("First method of output");
            Console.WriteLine("Your name is " + name + ", your surname is " + surname + ", your age is " + age + ", your height is " + height + ", your weight is " + weight);
            Console.ReadLine();
            Console.WriteLine("Second method of output");
            Console.WriteLine("Your name is {0}, your surname is {1}, your age is {2}, your height is {3}, your weight is {4}", name, surname, age, height, weight);
            Console.ReadLine();
            Console.WriteLine("Third method of output");
            Console.WriteLine($"Your name is {name}, your surname is {surname}, your age is {age}, your height is {height}, your weight is {weight}");
            Console.ReadLine();
        }
    }
}
