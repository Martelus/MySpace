﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ_C_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //а) Написать программу, которая подсчитывает расстояние между точками с координатами x1, y1 и x2,y2 
            //по формуле r = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2).
            //Вывести результат, используя спецификатор формата .2f(с двумя знаками после запятой);
            //б) *Выполнить предыдущее задание, оформив вычисления расстояния между точками в виде метода.
            Console.WriteLine("Enter coordinates of point 1 (x)");
            int x1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter coordinates of point 1 (y)");
            int y1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter coordinates of point 2 (x)");
            int x2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter coordinates of point 2 (y)");
            int y2 = int.Parse(Console.ReadLine());
            double distance = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
            Console.WriteLine("Distance between the points is {0:0.00}", distance);
            Console.ReadLine();
        }
    }
}
