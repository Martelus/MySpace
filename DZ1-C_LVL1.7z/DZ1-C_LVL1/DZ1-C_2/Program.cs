﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ1_C_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ввести вес и рост человека.Рассчитать и вывести индекс массы тела(ИМТ) по формуле I = m / (h * h); 
            //где m — масса тела в килограммах, h — рост в метрах.
            Console.WriteLine("Enter weight");
            int weight = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter height (in meters)");
            int height = int.Parse(Console.ReadLine());
            double b_ind = (weight / (height * height));
            Console.WriteLine("Your body index = " + b_ind);
            Console.ReadLine();
        }
    }
}
