﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ1_C_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first variable");
            var fvar = Console.ReadLine();
            Console.WriteLine("Enter second vaariable");
            var svar = Console.ReadLine();
            var tvar = fvar;
            fvar = svar;
            svar = tvar;
            Console.WriteLine("After convertin by places the variables is {0} and {1}", fvar, svar);
            Console.ReadLine();
        }
    }
}
